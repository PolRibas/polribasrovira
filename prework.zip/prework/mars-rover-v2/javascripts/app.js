// Rover Object Goes Here
var rover = {
  direction: "N",
  x: 0,
  y: 0,
  travelLog: ["0-0"],
}

var roverSo = {
  direction: "N",
  x: 6,
  y: 6,
  travelLog: ["6-6"],
}

var obstacle = {
  x: 3,
  y: 2
}

// Contador de movimientos
var j = 0;
var k = 0;

// ======================
var i = null;
var move = null;

// move String
var roverOne = 'brffffffffffflbbbbblrrfffffrbblbbrffffrfflfflfrffff';
var roverTwo = 'brrbblfflfflfllfffflfffrbblfff'

if(roverOne.length > roverTwo.length){
  move = roverOne.length;
}else{
  move = roverTwo.length
}

for(i = 0; i <= move - 1; i++){
  if(roverOne[i] == 'r'){
    turnRight(rover);
  }else if(roverOne[i] == 'l'){
    turnLeft(rover);
  }else if(roverOne[i] == 'f'){
    moveForward(rover, obstacle);
  }else if(roverOne[i] == 'b'){
    moveBackwards(rover, obstacle);
  }
  if(roverTwo[i] == 'r'){
    turnRight(roverSo);
  }else if(roverTwo[i] == 'l'){
    turnLeft(roverSo);
  }else if(roverTwo[i] == 'f'){
    moveForward(roverSo, obstacle);
  }else if(roverTwo[i] == 'b'){
    moveBackwards(roverSo, obstacle);
  }
  if(rover.x == roverSo.x && rover.y == roverSo.y){
    console.log("We Have and accident, or rovers have crash");
    move = 0;
  }
  console.log(rover.x + ", " + rover.y);
  console.log(roverSo.x + ", " + roverSo.y);
}
console.log(rover.travelLog);
console.log(roverSo.travelLog);

// ======================
function turnLeft(rover){
  console.log("turnLeft was called!");
    switch (rover.direction) {
      case "N":
         rover.direction = "W";
        break;
      case "W":
         rover.direction = "S";
        break;
      case "S":
         rover.direction = "E";
        break;
      case "E":
         rover.direction = "N";
        break;
      default:
        break;
    }
    return rover;
}

function turnRight(rover){
  console.log("turnRight was called!");
    switch (rover.direction) {
      case "N":
         rover.direction = "E";
        break;
      case "W":
         rover.direction = "N";
        break;
      case "S":
         rover.direction = "W";
        break;
      case "E":
         rover.direction = "S";
        break;
      default:
        break;
    }
    return rover;
}

function moveForward(rover, obstacle){
  console.log("moveForward was called");
    switch (rover.direction) {
      case "N":
        rover.y--;
          // restrictions: obstacle and 10x10
          if(rover.y < 0 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.y++;
            j--;
          }
        break;
      case "W":
        rover.x--;
          // restrictions: obstacle and 10x10
          if(rover.x < 0 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.x++;
            j--;
          }
        break;
      case "S":
        rover.y++;
          // restrictions: obstacle and 10x10
          if(rover.y > 9 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.y--;
            j--;
          }
        break;
      case "E":
        rover.x++;
          // restrictions: obstacle and 10x10
          if(rover.x > 9 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.x--;
            j--;
          }
        break;
      default:
        break;
    }
    j++;
    rover.travelLog[j] = rover.x + "-" + rover.y;
    return rover;
}

function moveBackwards(rover, obstacle){
  console.log("moveBackwards was called");
    switch (rover.direction) {
      case "S":
        rover.y--;
          // restrictions: obstacle and 10x10
          if(rover.y < 0 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.y++;
            j--;
          }
        break;
      case "E":
        rover.x--;
          // restrictions: obstacle and 10x10
          if(rover.x < 0 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.x++;
            j--;
          }
        break;
      case "N":
        rover.y++;
          // restrictions: obstacle and 10x10
          if(rover.y > 9 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.y--;
            j--;
          }
        break;
      case "W":
        rover.x++;
          // restrictions: obstacle and 10x10
          if(rover.x > 9 || rover.x == obstacle.x && rover.y == obstacle.y){
            rover.x--;
            j--;
          }
        break;
      default:
        break;
    }
    j++;
    rover.travelLog[j] = rover.x + "-" + rover.y;
    return rover;
}
